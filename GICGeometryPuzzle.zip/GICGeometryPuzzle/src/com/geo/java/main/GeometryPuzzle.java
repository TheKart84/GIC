package com.geo.java.main;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import com.vividsolutions.jts.algorithm.locate.SimplePointInAreaLocator;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;

public class GeometryPuzzle {
	static Set<String> set;
	private static BufferedReader reader;

    public GeometryPuzzle(BufferedReader br) {
    	this.reader = br;
    }
	
	public static void main(String[] args) throws IOException {
		reader = new BufferedReader(new InputStreamReader(System.in));
		puzzle();
	}
	public static void puzzle() throws IOException {
		set = new LinkedHashSet<String>();
		System.out.println("Welcome to the GIC geometry puzzle app\r\n" + "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape");
		String temp = reader.readLine();
		if (Integer.parseInt(temp) == 1) {
			Polygon poly = customShape(false);
			geoPuzzle(poly);
	
		} else {
			Polygon poly = customShape(true);
			geoPuzzle(poly);
		}
		reader.close();
	}
	public static Polygon customShape(boolean flag) throws IOException {

		Polygon poly = null;
		int count = 1;
		for (;;) {
			if (count > 8 && flag) {
				System.out.println("Your random shape is");
				AtomicInteger counter = new AtomicInteger();
				set.stream().forEach(value -> {
					counter.getAndIncrement();
					System.out.println(counter.get() + ":(" + value + ")");
				});

				break;
			}
			if (count > 3) {
				System.out.println(
						"Please enter # to finalize your shape or enter coordinates " + count + "  in x y format");
			} else {
				System.out.println("Please enter coordinates " + count + " in x y format");
			}

			//Scanner in1 = new Scanner(System.in);
			String s =  reader.readLine();
			if ("#".equalsIgnoreCase(s)) {
				System.out.println("Your finalized shape is");
				AtomicInteger counter = new AtomicInteger();
				set.stream().forEach(value -> {
					counter.getAndIncrement();
					System.out.println(counter.get() + ":(" + value + ")");
				});
				break;
			}
			String[] splited = s.split("\\s+");
			boolean check = set.add(splited[0] + "," + splited[1]);
			if (!check) {
				System.out.println("New coordinates(" + (splited[0] + "," + splited[1]) + ") is invalid!!! \r\n"
						+ "Not adding new coordinates to the current shape.\r\n");
				if (count < 3) {
					System.out.println("Your current shape is incomplete");
				} else {
					System.out.println("Your current shape is complete");
				}
				AtomicInteger counter = new AtomicInteger();
				set.stream().forEach(value -> {
					counter.getAndIncrement();
					System.out.println(counter.get() + ":(" + value + ")");
				});

			} else {
				if (count < 3) {
					System.out.println("Your current shape is incomplete");
					AtomicInteger counter = new AtomicInteger();
					set.stream().forEach(value -> {
						counter.getAndIncrement();
						System.out.println(counter.get() + ":(" + value + ")");
					});
				}
				if (count >= 3) {
					GeometryFactory geometryFactory = new GeometryFactory();
					ArrayList<Coordinate> points = new ArrayList<Coordinate>();
					Iterator<String> it = set.iterator();
					String first = "";
					int count1 = 0;
					while (it.hasNext()) {
						String coords = it.next();
						if (count1 == 0) {
							first = coords;
						}
						String[] coord = coords.split(",");
						points.add(new Coordinate(Integer.parseInt(coord[0]), Integer.parseInt(coord[1])));

						count1++;
					}
					String[] firstSplit = first.split(",");
					points.add(new Coordinate(Integer.parseInt(firstSplit[0]), Integer.parseInt(firstSplit[1])));
					poly = geometryFactory.createPolygon((Coordinate[]) points.toArray(new Coordinate[] {}));
					if (poly.isValid()) {
						System.out.println("Your current shape is valid and is complete");
						AtomicInteger counter = new AtomicInteger();
						set.stream().forEach(value -> {
							counter.getAndIncrement();
							System.out.println(counter.get() + ":(" + value + ")");
						});
					} else {
						System.out.println("New coordinates(" + (splited[0] + "," + splited[1]) + ") is invalid!!! \r\n"
								+ "Not adding new coordinates to the current shape.\r\n");
						set.remove(splited[0] + "," + splited[1]);
						count--;
						System.out.println("Your current shape is valid and is complete");
						AtomicInteger counter = new AtomicInteger();
						set.stream().forEach(value -> {
							counter.getAndIncrement();
							System.out.println(counter.get() + ":(" + value + ")");
						});
					}
				}
				count++;
			}
		}
		return poly;

	}

	private static void geoPuzzle(Polygon poly) throws IOException {
		for (;;) {
			System.out.println("Please key in test coordinates in x y format or enter # to quit the game");
		//	Scanner in2 = new Scanner(System.in);
			String temp =  reader.readLine();
			if ("#".equalsIgnoreCase(temp)) {
				System.out.println("Thank you for playing the GIC geometry puzzle app\r\n" + "Have a nice day!");
			break;
			} else {
				String[] splited = temp.split("\\s+");
				boolean puzzle = SimplePointInAreaLocator.containsPointInPolygon(
						new Coordinate(Integer.parseInt(splited[0]), Integer.parseInt(splited[1])), poly);
				System.out.println("Your finalized shape is");
				AtomicInteger counter = new AtomicInteger();
				set.stream().forEach(value -> {
					counter.getAndIncrement();
					System.out.println(counter.get() + ":(" + value + ")");
				});
				if (puzzle) {
					System.out.println(
							"Coordinates (" + (splited[0] + "," + splited[1]) + ") is within your finalized shape\r\n");
				} else {
					System.out.println("Sorry, coordinates (" + (splited[0] + "," + splited[1])
							+ ") is outside of your finalized shape");
				}

			}
		}
	}
}
