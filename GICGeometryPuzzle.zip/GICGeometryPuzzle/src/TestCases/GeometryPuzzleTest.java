package TestCases;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;

import com.geo.java.main.GeometryPuzzle;

public class GeometryPuzzleTest {

	@Test
	public void customShapeTest() throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new StringReader("1\n1\s1\n5\s1\n5\s5\n#\n#"));
		GeometryPuzzle puzzle = new GeometryPuzzle(bufferedReader);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    System.setOut(new PrintStream(outContent));
		puzzle.puzzle();
		String s = "Welcome to the GIC geometry puzzle app\r\n"
				+ "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape\r\n"
				+ "Please enter coordinates 1 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "Please enter coordinates 2 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "Please enter coordinates 3 in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Thank you for playing the GIC geometry puzzle app\r\n"
				+ "Have a nice day!\n";
		Assert.assertEquals(s.trim(),outContent.toString().trim());
		outContent.close();
		bufferedReader.close();
	}
	@Test
	public void randomShapeTest() throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new StringReader("2\n1\s1\n1\s4\n2\s6\n3\s9\n4\s10\n6\s15\n15\s4\n10\s6\n#"));
		GeometryPuzzle puzzle = new GeometryPuzzle(bufferedReader);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    System.setOut(new PrintStream(outContent));
		puzzle.puzzle();
		String s = "Welcome to the GIC geometry puzzle app\r\n"
				+ "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape\r\n"
				+ "Please enter coordinates 1 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "Please enter coordinates 2 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "Please enter coordinates 3 in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 5  in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "5:(4,10)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 6  in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "5:(4,10)\r\n"
				+ "6:(6,15)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 7  in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "5:(4,10)\r\n"
				+ "6:(6,15)\r\n"
				+ "7:(15,4)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 8  in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "5:(4,10)\r\n"
				+ "6:(6,15)\r\n"
				+ "7:(15,4)\r\n"
				+ "8:(10,6)\r\n"
				+ "Your random shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(1,4)\r\n"
				+ "3:(2,6)\r\n"
				+ "4:(3,9)\r\n"
				+ "5:(4,10)\r\n"
				+ "6:(6,15)\r\n"
				+ "7:(15,4)\r\n"
				+ "8:(10,6)\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Thank you for playing the GIC geometry puzzle app\r\n"
				+ "Have a nice day!\r\n";
		Assert.assertEquals(s.trim(),outContent.toString().trim());
		outContent.close();
		bufferedReader.close();
	}
	@Test
	public void validInputCheckTest() throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new StringReader("1\n1\s1\n5\s1\n5\s5\n1\s1\n#\n#"));
		GeometryPuzzle puzzle = new GeometryPuzzle(bufferedReader);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    System.setOut(new PrintStream(outContent));
		puzzle.puzzle();
		String s = "Welcome to the GIC geometry puzzle app\r\n"
				+ "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape\r\n"
				+ "Please enter coordinates 1 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "Please enter coordinates 2 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "Please enter coordinates 3 in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "New coordinates(1,1) is invalid!!! \r\n"
				+ "Not adding new coordinates to the current shape.\r\n"
				+ "\r\n"
				+ "Your current shape is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Thank you for playing the GIC geometry puzzle app\r\n"
				+ "Have a nice day!";
		Assert.assertEquals(s.trim(),outContent.toString().trim());
		outContent.close();
		bufferedReader.close();
	}
	@Test
	public void checkWithInFinalisedShapeTest() throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new StringReader("1\n1\s1\n5\s1\n5\s5\n#\n5\s1\n#"));
		GeometryPuzzle puzzle = new GeometryPuzzle(bufferedReader);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    System.setOut(new PrintStream(outContent));
		puzzle.puzzle();
		String s = "Welcome to the GIC geometry puzzle app\r\n"
				+ "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape\r\n"
				+ "Please enter coordinates 1 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "Please enter coordinates 2 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "Please enter coordinates 3 in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Coordinates (5,1) is within your finalized shape\r\n"
				+ "\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Thank you for playing the GIC geometry puzzle app\r\n"
				+ "Have a nice day!";
		Assert.assertEquals(s.trim(),outContent.toString().trim());
		outContent.close();
		bufferedReader.close();
	}
	@Test
	public void checkOutsideShapeTest() throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new StringReader("1\n1\s1\n5\s1\n5\s5\n#\n0\s1\n#"));
		GeometryPuzzle puzzle = new GeometryPuzzle(bufferedReader);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	    System.setOut(new PrintStream(outContent));
		puzzle.puzzle();
		String s = "Welcome to the GIC geometry puzzle app\r\n"
				+ "[1] Create a custom shape \r\n"
				+ "[2] Generate a random shape\r\n"
				+ "Please enter coordinates 1 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "Please enter coordinates 2 in x y format\r\n"
				+ "Your current shape is incomplete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "Please enter coordinates 3 in x y format\r\n"
				+ "Your current shape is valid and is complete\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please enter # to finalize your shape or enter coordinates 4  in x y format\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Your finalized shape is\r\n"
				+ "1:(1,1)\r\n"
				+ "2:(5,1)\r\n"
				+ "3:(5,5)\r\n"
				+ "Sorry, coordinates (0,1) is outside of your finalized shape\r\n"
				+ "Please key in test coordinates in x y format or enter # to quit the game\r\n"
				+ "Thank you for playing the GIC geometry puzzle app\r\n"
				+ "Have a nice day!";
		Assert.assertEquals(s.trim(),outContent.toString().trim());
		outContent.close();
		bufferedReader.close();
	}
}